% Startscript 2015/05/29
%
% written by Simon D. Schmidt
ETSversionName = 'ETS - Version Shanghai';
ETSversionNumber = 10;

installpath = cd;
temppath = tempdir;
tempfile = [temppath,'updateETS.m'];
serverpath = 'http://www.sidash.de/ETS/';
updatepath = [serverpath,'update.m'];
versionpath = [serverpath,'version'];

path(pathdef); 
try
    sds.MWC.stopAll;
    delete(sds);
    clear sds;
catch
end

disp('Checking for Updates')
newUpdate = 0;
try
    updateversion = str2double(urlread(versionpath));
    if updateversion > ETSversionNumber
        newUpdate = 1;
    end
catch
    newUpdate = -1;
end

switch newUpdate
    case 0
        disp('No new updates available ...')
    case 1
        disp('New updates available, updating ...')
        try
            urlwrite(updatepath,tempfile);
        catch
            disp(['Could not retrieve ',updatepath]);
        end
        
        try
            addpath(temppath);
            updateETS(installpath);
            delete(tempfile);
            disp('Update successfull, exiting')
            exit;
        catch
            disp(['Could not update ',updatepath]);
        end
    case -1
        disp('Checking for updates failed, continuing ...')
end

clear installpath temppath tempfile serverpath updatepath versionpath;

%%
try
addpath([cd,'/include/']);
addpath(cd);
catch
    error('Path ./include not found. Make sure you are in the directory of the start-file')
end

% Try to stop
try
    sds.MWC.stopAll;
    delete(sds);
    clear sds;
catch
end

% Try to delete previous
try
    delete(sds);
    clear sds;
catch
end

% Create new MeasureWindClass_GUI object
configFile = ([cd,'/SDSconfig.m']);
sds = MeasureWindClass_GUI(configFile);

%clc;
disp(ETSversionName)
sds.updateGUI